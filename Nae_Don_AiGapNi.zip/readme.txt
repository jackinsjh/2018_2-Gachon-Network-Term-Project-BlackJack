-Notice
This program needs ID_PW_List.dat file to be in the project folder to run. 
This file can be empty at first time. This file is used to manage all user's IDs and passwords.